namespace HP.System.Data
{
	class DataEntry
	{
	private:
		string key;
		int value;
		string value;
		double value;
		int valuetype;

		DataEntry(string key);

	};
	class DataRow
	{
		public:
			DataRow()
			{
			}
	};
	class DataTable
	{

		public:
			DataTable()
			{

			}
	};
}