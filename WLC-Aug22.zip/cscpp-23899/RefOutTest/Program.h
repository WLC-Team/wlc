#pragma once

namespace RefOutTest
{
    ref class Program
    {
        private: static void Main();
    };
}

