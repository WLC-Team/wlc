namespace Converters.Dtos
{
    public interface IFullName
    {
        string FullName { get; }
    }
}